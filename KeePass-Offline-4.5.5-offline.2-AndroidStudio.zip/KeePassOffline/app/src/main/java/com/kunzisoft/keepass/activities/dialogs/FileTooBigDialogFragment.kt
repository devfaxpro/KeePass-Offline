/*
 * Copyright 2019 Jeremy Jamet / Kunzisoft.
 *
 * This file is part of KeePassDX.
 *
 *  KeePassDX is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  KeePassDX is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with KeePassDX.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package com.kunzisoft.keepass.activities.dialogs

import android.app.Dialog
import android.net.Uri
import android.os.Bundle
import android.text.SpannableStringBuilder
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import com.kunzisoft.keepass.R
import com.kunzisoft.keepass.utils.getParcelableCompat
import com.kunzisoft.keepass.viewmodels.AttachmentsViewModel

/**
 * Custom Dialog to confirm big file to upload
 */
class FileTooBigDialogFragment : DialogFragment() {

    private val attachmentsViewModel: AttachmentsViewModel by activityViewModels()

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        activity?.let { activity ->
            // Use the Builder class for convenient dialog construction
            val builder = AlertDialog.Builder(activity)
            builder.setMessage(SpannableStringBuilder().apply {
                append(getString(R.string.warning_file_too_big))
                append("\n\n")
                append(getString(R.string.warning_sure_add_file))
            })
            builder.setPositiveButton(android.R.string.ok) { _, _ ->
                val uri = arguments?.getParcelableCompat<Uri>(KEY_FILE_URI)
                val fileName = arguments?.getString(KEY_FILE_NAME)
                if (uri != null && fileName != null) {
                    attachmentsViewModel.buildNewAttachment(uri, fileName)
                } // TODO Error
            }
            builder.setNegativeButton(android.R.string.cancel) { _, _ ->
                dismiss()
            }
            // Create the AlertDialog object and return it
            return builder.create()
        }
        return super.onCreateDialog(savedInstanceState)
    }

    companion object {
        const val MAX_WARNING_BINARY_FILE = 5242880

        private const val KEY_FILE_URI = "KEY_FILE_URI"
        private const val KEY_FILE_NAME = "KEY_FILE_NAME"

        fun build(
            attachmentToUploadUri: Uri,
            fileName: String,
        ): FileTooBigDialogFragment {
            val fragment = FileTooBigDialogFragment()
            fragment.arguments = Bundle().apply {
                putParcelable(KEY_FILE_URI, attachmentToUploadUri)
                putString(KEY_FILE_NAME, fileName)
            }
            return fragment
        }
    }
}
