/*
 * Copyright 2021 Jeremy Jamet / Kunzisoft.
 *
 * This file is part of KeePassDX.
 *
 *  KeePassDX is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  KeePassDX is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with KeePassDX.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package com.kunzisoft.keepass.database

import android.content.Context
import android.net.Uri
import android.util.Log
import com.kunzisoft.keepass.database.element.EntryId
import com.kunzisoft.keepass.database.element.GroupId
import com.kunzisoft.keepass.database.element.icon.IconImage
import com.kunzisoft.keepass.database.element.icon.IconImageCustom
import com.kunzisoft.keepass.database.element.icon.IconImageStandard
import com.kunzisoft.keepass.icons.IconDrawableFactory
import com.kunzisoft.keepass.model.DatabaseInfo
import com.kunzisoft.keepass.model.EntryInfo
import com.kunzisoft.keepass.model.RegisterInfo
import com.kunzisoft.keepass.model.SnapFileDatabaseInfo
import com.kunzisoft.keepass.utils.SingletonHolder
import com.kunzisoft.keepass.viewmodels.FileDatabaseInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

class ContextualDatabase: DatabaseInfo() {

    // Database file URI
    var fileUri: Uri? = null

    // To reload the main activity
    var wasReloaded = false

    // File description
    var snapFileDatabaseInfo: SnapFileDatabaseInfo? = null
        private set

    // To defined if unsaved data still remaining
    private val mDataModifiedSinceLastLoading = MutableStateFlow(false)
    val dataModifiedSinceLastLoadingFlow = mDataModifiedSinceLastLoading.asStateFlow()
    val dataModifiedSinceLastLoading: Boolean
        get() = mDataModifiedSinceLastLoading.value

    // Factory to draw icons
    val iconDrawableFactory = IconDrawableFactory(
        retrieveBinaryCache = { binaryCache },
        retrieveCustomIconBinary = { iconId -> getBinaryForCustomIcon(iconId) }
    )

    /**
     * Save the database file info
     */
    fun saveDatabaseInfo(context: Context) {
        try {
            fileUri?.let {
                snapFileDatabaseInfo = SnapFileDatabaseInfo.fromFileDatabaseInfo(
                    FileDatabaseInfo(context, it))
                Log.i(TAG, "Database file saved $snapFileDatabaseInfo")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Unable to save database info", e)
        }
    }

    /**
     * Indicate that the database has unsaved data still remaining,
     * Data are not necessarily changed from the app
     */
    fun indicateNotSavedData() {
        mDataModifiedSinceLastLoading.value = true
    }

    /**
     * Indicate that data in the database is up to date
     */
    fun indicateUpToDateData() {
        mDataModifiedSinceLastLoading.value = false
    }

    /**
     * Build entry info to create.
     * @param parentId The parent ID to use.
     * @param registerInfo The registration info to use.
     * @return The created entry info if successful, null otherwise.
     */
    suspend fun buildNewEntryInfo(
        parentId: GroupId,
        registerInfo: RegisterInfo? = null
    ): EntryInfo? {
        getGroupById(parentId)?.let { parentGroup ->
            val entry = createEntry()?.apply {
                // Add the default icon from parent if not a folder
                val parentIcon = parentGroup.icon
                // Set default icon
                if (parentIcon.custom.isUnknown
                    && parentIcon.standard.id != IconImageStandard.FOLDER_ID
                ) {
                    icon = IconImage(parentIcon.standard)
                }
                if (!parentIcon.custom.isUnknown) {
                    icon = IconImage(parentIcon.custom)
                }
                // Set default username
                username = defaultUsername
            }
            var entryInfo: EntryInfo? = null
            // Decode the entry / load entry info
            entry?.let {
                getEntryInfoFrom(entry = entry, raw = true).let { tempEntryInfo ->
                    // Retrieve data from registration
                    registerInfo?.let { regInfo ->
                        saveRegisterInfoIn(tempEntryInfo, regInfo)
                    }
                    entryInfo = tempEntryInfo
                }
            }
            return entryInfo
        }
        return null
    }

    /**
     * Build entry info to update.
     * @param entryId The entry ID to update.
     * @param registerInfo The registration info to use.
     * @param actionDataOverwrite The action to perform when data is overwritten.
     */
    suspend fun buildEntryInfoFrom(
        entryId: EntryId,
        registerInfo: RegisterInfo? = null,
        actionDataOverwrite: suspend () -> Unit = {}
    ): EntryInfo? {
        getEntryInfoById(entryId = entryId, raw = true)?.let { tempEntryInfo ->
            // Retrieve data from registration
            registerInfo?.let { regInfo ->
                if (saveRegisterInfoIn(tempEntryInfo, regInfo))
                    actionDataOverwrite()
            }
            return tempEntryInfo
        }
        return null
    }

    override fun removeCustomIcon(customIcon: IconImageCustom) {
        iconDrawableFactory.clearFromCache(customIcon)
        super.removeCustomIcon(customIcon)
    }

    override fun clearIndexesAndBinaries(filesDirectory: File?) {
        iconDrawableFactory.clearCache()
        super.clearIndexesAndBinaries(filesDirectory)
    }

    override fun clearAndClose(filesDirectory: File?) {
        super.clearAndClose(filesDirectory)
        this.fileUri = null
    }

    companion object : SingletonHolder<ContextualDatabase>(::ContextualDatabase) {
        private val TAG = ContextualDatabase::class.java.name
    }
}