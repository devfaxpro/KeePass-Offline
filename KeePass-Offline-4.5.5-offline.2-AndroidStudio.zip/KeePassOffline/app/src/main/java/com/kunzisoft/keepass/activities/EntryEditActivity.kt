/*
 * Copyright 2019 Jeremy Jamet / Kunzisoft.
 *     
 * This file is part of KeePassDX.
 *
 *  KeePassDX is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  KeePassDX is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with KeePassDX.  If not, see <http://www.gnu.org/licenses/>.
 */
package com.kunzisoft.keepass.activities

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ProgressBar
import android.widget.Spinner
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.core.view.isVisible
import androidx.core.widget.NestedScrollView
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.snackbar.Snackbar
import com.google.android.material.timepicker.MaterialTimePicker.Builder
import com.kunzisoft.keepass.R
import com.kunzisoft.keepass.activities.dialogs.ColorPickerDialogFragment
import com.kunzisoft.keepass.activities.dialogs.DiscardChangesDialogFragment
import com.kunzisoft.keepass.activities.dialogs.EntryCustomFieldDialogFragment
import com.kunzisoft.keepass.activities.dialogs.FileTooBigDialogFragment
import com.kunzisoft.keepass.activities.dialogs.FileTooBigDialogFragment.Companion.MAX_WARNING_BINARY_FILE
import com.kunzisoft.keepass.activities.dialogs.OverwriteDataDialogFragment
import com.kunzisoft.keepass.activities.dialogs.ReplaceFileDialogFragment
import com.kunzisoft.keepass.activities.fragments.EntryEditFragment
import com.kunzisoft.keepass.activities.helpers.ExternalFileHelper
import com.kunzisoft.keepass.activities.legacy.DatabaseLockActivity
import com.kunzisoft.keepass.adapters.TemplatesSelectorAdapter
import com.kunzisoft.keepass.credentialprovider.EntrySelectionHelper
import com.kunzisoft.keepass.credentialprovider.EntrySelectionHelper.buildSpecialModeResponseAndSetResult
import com.kunzisoft.keepass.credentialprovider.EntrySelectionHelper.retrieveRegisterInfo
import com.kunzisoft.keepass.credentialprovider.EntrySelectionHelper.retrieveSearchInfo
import com.kunzisoft.keepass.credentialprovider.TypeMode
import com.kunzisoft.keepass.credentialprovider.UserVerificationActionType
import com.kunzisoft.keepass.credentialprovider.UserVerificationData
import com.kunzisoft.keepass.credentialprovider.UserVerificationHelper.Companion.checkUserVerification
import com.kunzisoft.keepass.credentialprovider.passkey.util.PasskeyHelper.buildPasskeyResponseAndSetResult
import com.kunzisoft.keepass.credentialprovider.passkey.util.PasswordHelper.buildPasswordResponseAndSetResult
import com.kunzisoft.keepass.database.ContextualDatabase
import com.kunzisoft.keepass.database.element.Attachment
import com.kunzisoft.keepass.database.element.DateInstant
import com.kunzisoft.keepass.database.element.EntryId
import com.kunzisoft.keepass.database.element.Field
import com.kunzisoft.keepass.database.element.GroupId
import com.kunzisoft.keepass.database.element.node.NodeId
import com.kunzisoft.keepass.database.element.security.ProtectedString
import com.kunzisoft.keepass.education.EntryEditActivityEducation
import com.kunzisoft.keepass.model.DataTime
import com.kunzisoft.keepass.model.EntryAttachmentState
import com.kunzisoft.keepass.model.EntryInfo
import com.kunzisoft.keepass.model.RegisterInfo
import com.kunzisoft.keepass.model.SearchInfo
import com.kunzisoft.keepass.services.AttachmentFileNotificationService
import com.kunzisoft.keepass.services.DatabaseTaskNotificationService.Companion.ACTION_DATABASE_CREATE_ENTRY_TASK
import com.kunzisoft.keepass.services.DatabaseTaskNotificationService.Companion.ACTION_DATABASE_UPDATE_ENTRY_TASK
import com.kunzisoft.keepass.services.DatabaseTaskNotificationService.Companion.getNewEntry
import com.kunzisoft.keepass.services.KeyboardEntryNotificationService
import com.kunzisoft.keepass.settings.PreferencesUtil
import com.kunzisoft.keepass.tasks.ActionRunnable
import com.kunzisoft.keepass.tasks.AttachmentFileBinderManager
import com.kunzisoft.keepass.timeout.TimeoutHelper
import com.kunzisoft.keepass.utils.TimeUtil.datePickerToDataDate
import com.kunzisoft.keepass.utils.UriUtil.getDocumentFile
import com.kunzisoft.keepass.utils.clear
import com.kunzisoft.keepass.utils.getParcelableExtraCompat
import com.kunzisoft.keepass.view.ToolbarAction
import com.kunzisoft.keepass.view.WindowInsetPosition
import com.kunzisoft.keepass.view.applyWindowInsets
import com.kunzisoft.keepass.view.asError
import com.kunzisoft.keepass.view.hideByFading
import com.kunzisoft.keepass.view.setTransparentNavigationBar
import com.kunzisoft.keepass.view.showByFading
import com.kunzisoft.keepass.view.showError
import com.kunzisoft.keepass.view.updateButtonPaddingEnd
import com.kunzisoft.keepass.view.updateButtonPaddingStart
import com.kunzisoft.keepass.viewmodels.AttachmentsViewModel
import com.kunzisoft.keepass.viewmodels.ColorPickerViewModel
import com.kunzisoft.keepass.viewmodels.EntryEditViewModel
import com.kunzisoft.keepass.viewmodels.NodeEditViewModel
import com.kunzisoft.keepass.viewmodels.UserVerificationViewModel
import kotlinx.coroutines.launch
import java.util.EnumSet

class EntryEditActivity : DatabaseLockActivity() {

    // Views
    private var container: View? = null
    private var coordinatorError: CoordinatorLayout? = null
    private var coordinatorLayout: CoordinatorLayout? = null
    private var scrollView: NestedScrollView? = null
    private var templateSelectorSpinner: Spinner? = null
    private var entryEditAddToolBar: ToolbarAction? = null
    private var validateButton: View? = null
    private var lockView: View? = null
    private var loadingView: ProgressBar? = null

    private val mEntryEditViewModel: EntryEditViewModel by viewModels()
    private val mAttachmentsViewModel: AttachmentsViewModel by viewModels()
    private var mTemplatesSelectorAdapter: TemplatesSelectorAdapter? = null

    private val mColorPickerViewModel: ColorPickerViewModel by viewModels()
    private val mUserVerificationViewModel: UserVerificationViewModel by viewModels()

    // To manage attachments
    private var mExternalFileHelper: ExternalFileHelper? = null
    private var mAttachmentFileBinderManager: AttachmentFileBinderManager? = null
    // Education
    private var mEntryEditActivityEducation = EntryEditActivityEducation(this)

    private var mIconSelectionActivityResultLauncher = IconPickerActivity.registerIconSelectionForResult(this) { icon ->
        mEntryEditViewModel.selectIcon(icon)
    }

    private var mKeyGeneratorResultLauncher = KeyGeneratorActivity.registerForGeneratedKeyResult(this) { keyGenerated ->
        keyGenerated?.let {
            mEntryEditViewModel.passwordField?.let {
                it.protectedValue = ProtectedString(
                    it.protectedValue.isProtected,
                    keyGenerated
                )
                mEntryEditViewModel.selectPassword(it)
                keyGenerated.clear()
            }
        }
        mEntryEditViewModel.passwordField = null
        Handler(Looper.getMainLooper()).post {
            performedNextEducation()
        }
    }

    override fun manageDatabaseInfo(): Boolean = true

    override fun errorCoordinatorView(): View? = coordinatorError

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_entry_edit)

        // Bottom Bar
        entryEditAddToolBar = findViewById(R.id.entry_edit_bottom_bar)
        container = findViewById(R.id.activity_entry_edit_container)
        coordinatorError = findViewById(R.id.error_coordinator)
        coordinatorLayout = findViewById(R.id.entry_edit_coordinator_layout)
        scrollView = findViewById(R.id.entry_edit_scroll)
        scrollView?.scrollBarStyle = View.SCROLLBARS_INSIDE_INSET
        templateSelectorSpinner = findViewById(R.id.entry_edit_template_selector)
        lockView = findViewById(R.id.lock_button)
        validateButton = findViewById(R.id.entry_edit_validate)
        loadingView = findViewById(R.id.loading)

        setSupportActionBar(entryEditAddToolBar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)
        supportActionBar?.setDisplayShowTitleEnabled(false)

        // To apply fit window with transparency
        setTransparentNavigationBar(applyToStatusBar = true) {
            container?.applyWindowInsets(EnumSet.of(
                WindowInsetPosition.TOP_MARGINS,
                WindowInsetPosition.BOTTOM_MARGINS,
                WindowInsetPosition.START_MARGINS,
                WindowInsetPosition.END_MARGINS,
            ))
        }

        stopService(Intent(this, KeyboardEntryNotificationService::class.java))

        mEntryEditViewModel.loadTemplateEntry(
            // Entry is retrieve, it's an entry to update
            entryId = intent.getParcelableExtraCompat<EntryId>(KEY_ENTRY),
            // Parent is retrieve, it's a new entry to create
            parentId = intent.getParcelableExtraCompat<GroupId>(KEY_PARENT),
            // Register info from search
            registerInfo = intent.retrieveRegisterInfo()
                ?: intent.retrieveSearchInfo()?.toRegisterInfo()
        )

        // To retrieve attachment
        mExternalFileHelper = ExternalFileHelper(this)
        mExternalFileHelper?.buildOpenDocument { uri ->
            uri?.let { attachmentToUploadUri ->
                attachmentToUploadUri.getDocumentFile(this)?.also { documentFile ->
                    documentFile.name?.let { fileName ->
                        if (documentFile.length() > MAX_WARNING_BINARY_FILE) {
                            FileTooBigDialogFragment.build(attachmentToUploadUri, fileName)
                                .show(supportFragmentManager, "fileTooBigFragment")
                        } else {
                            mAttachmentsViewModel.buildNewAttachment(attachmentToUploadUri, fileName)
                        }
                    }
                }
            }
        }

        mAttachmentFileBinderManager = AttachmentFileBinderManager(this)

        // Lock button
        lockView?.setOnClickListener { lockAndExit() }
        // Save button
        validateButton?.setOnClickListener { requestEntryValidation() }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    mEntryEditViewModel.entryEditUIState.collect { uiState ->
                        if (uiState.loaded)
                            loadingView?.hideByFading()
                        else
                            loadingView?.showByFading()

                        uiState.templates?.let { templatesData ->
                            val templates = templatesData.templates
                            val defaultTemplate = templatesData.defaultTemplate
                            templateSelectorSpinner?.apply {
                                // Build template selector
                                if (adapter == null) {
                                    if (templates.isNotEmpty()) {
                                        mTemplatesSelectorAdapter = TemplatesSelectorAdapter(
                                            this@EntryEditActivity,
                                            templates
                                        ).apply {
                                            iconDrawableFactory = mDatabase?.iconDrawableFactory
                                        }
                                        adapter = mTemplatesSelectorAdapter
                                        onItemSelectedListener =
                                            object : AdapterView.OnItemSelectedListener {
                                                override fun onItemSelected(
                                                    parent: AdapterView<*>?,
                                                    view: View?,
                                                    position: Int,
                                                    id: Long
                                                ) {
                                                    mEntryEditViewModel.changeTemplate(templates[position])
                                                }
                                                override fun onNothingSelected(parent: AdapterView<*>?) {}
                                            }
                                    } else {
                                        visibility = View.GONE
                                    }
                                }
                                setSelection(templates.indexOf(defaultTemplate))
                            }
                        }
                        invalidateOptionsMenu()
                    }
                }
                launch {
                    mEntryEditViewModel.entryEditEvents.collect { event ->
                        when (event) {
                            is EntryEditViewModel.EntryEditEvent.RequestPasswordSelection -> {
                                KeyGeneratorActivity.launch(
                                    context = this@EntryEditActivity,
                                    resultLauncher = mKeyGeneratorResultLauncher
                                )
                            }
                            is EntryEditViewModel.EntryEditEvent.RequestCustomFieldEdition -> {
                                editCustomField(event.field)
                            }
                            is EntryEditViewModel.EntryEditEvent.OnCustomFieldError -> {
                                coordinatorLayout?.let {
                                    Snackbar.make(it, R.string.error_field_name_already_exists, Snackbar.LENGTH_LONG)
                                        .asError()
                                        .show()
                                }
                            }
                            is EntryEditViewModel.EntryEditEvent.CreateEntry -> {
                                // Build new entry from the entry info retrieved
                                createEntry(
                                    parentId = event.parentId,
                                    entryInfo = event.newEntry
                                )
                            }
                            is EntryEditViewModel.EntryEditEvent.UpdateEntry -> {
                                updateEntry(event.entry)
                            }
                            is EntryEditViewModel.EntryEditEvent.CloseEntry -> {
                                mAttachmentFileBinderManager?.stopUploadAllAttachments()
                                when(event.closeType) {
                                    EntryEditViewModel.CloseType.DATABASE_BACK_PRESSED -> {
                                        super@EntryEditActivity.onDatabaseBackPressed()
                                    }
                                    EntryEditViewModel.CloseType.CANCEL_SPECIAL_MODE -> {
                                        super@EntryEditActivity.onCancelSpecialMode()
                                        finish()
                                    }
                                }
                            }
                            is EntryEditViewModel.EntryEditEvent.ScrollTo -> {
                                // Scroll to the attachment position
                                val offset = findViewById<View>(R.id.entry_edit_content).top
                                // Calculate position less 24px from top to show title
                                scrollView?.smoothScrollTo(
                                    0,
                                    (event.viewPosition + offset - 24).coerceAtLeast(0)
                                )
                            }
                            is EntryEditViewModel.EntryEditEvent.AskToDiscardChanges -> {
                                DiscardChangesDialogFragment.newInstance(event.closeType)
                                    .show(supportFragmentManager, "discardChangesDialog")
                            }
                            is EntryEditViewModel.EntryEditEvent.ShowOverwriteMessage -> {
                                OverwriteDataDialogFragment.newInstance()
                                    .show(supportFragmentManager, "overwriteDataDialog")
                            }
                            is EntryEditViewModel.EntryEditEvent.OnChangeFieldProtectionRequested -> {
                                mDatabase?.let { database ->
                                    val fieldProtection = event.fieldProtection
                                    if (mDatabaseAllowUserVerification
                                        && fieldProtection.needUserVerificationToReveal
                                        && !fieldProtection.isRevealed) {
                                        checkUserVerification(
                                            userVerificationViewModel = mUserVerificationViewModel,
                                            dataToVerify = UserVerificationData(
                                                actionType = UserVerificationActionType.SHOW_PROTECTED_FIELD,
                                                database = database,
                                                fieldProtection = fieldProtection
                                            )
                                        )
                                    } else {
                                        // Toggle field protection directly without user verification
                                        mEntryEditViewModel.updateFieldProtection(
                                            fieldProtection = fieldProtection,
                                            isRevealed = !fieldProtection.isRevealed
                                        )
                                    }
                                }
                            }
                            else -> {}
                        }
                    }
                }
                launch {
                    mEntryEditViewModel.nodeEditEvents.collect { event ->
                        when (event) {
                            is NodeEditViewModel.NodeEditEvent.RequestIconSelection -> {
                                IconPickerActivity.launch(
                                    context = this@EntryEditActivity,
                                    previousIcon = event.icon,
                                    resultLauncher = mIconSelectionActivityResultLauncher
                                )
                            }
                            is NodeEditViewModel.NodeEditEvent.OnIconSelected -> {}
                            is NodeEditViewModel.NodeEditEvent.RequestColorSelection -> {
                                ColorPickerDialogFragment.newInstance(event.color)
                                    .show(supportFragmentManager, "ColorPickerFragment")
                            }
                            is NodeEditViewModel.NodeEditEvent.RequestDateTimeSelection -> {
                                if (event.dateInstant.type == DateInstant.Type.TIME) {
                                    // Launch the time picker
                                    Builder().build().apply {
                                        addOnPositiveButtonClickListener {
                                            mEntryEditViewModel.selectTime(DataTime(this.hour, this.minute))
                                        }
                                        show(supportFragmentManager, "TimePickerFragment")
                                    }
                                } else {
                                    // Launch the date picker
                                    MaterialDatePicker.Builder.datePicker().build().apply {
                                        addOnPositiveButtonClickListener {
                                            mEntryEditViewModel.selectDate(datePickerToDataDate(it))
                                        }
                                        show(supportFragmentManager, "DatePickerFragment")
                                    }
                                }
                            }
                            else -> {}
                        }
                    }
                }
                launch {
                    mColorPickerViewModel.colorPicked.collect { color ->
                        mEntryEditViewModel.selectColor(color)
                    }
                }
                launch {
                    mAttachmentsViewModel.attachmentEvents.collect { event ->
                        when (event) {
                            is AttachmentsViewModel.AttachmentEvent.OnBuildNewAttachment -> {
                                mDatabaseViewModel.buildNewBinaryAttachment()?.let { binaryAttachment ->
                                    mAttachmentsViewModel.onNewBinaryAttachmentBuilt(
                                        attachment = Attachment(event.fileName, binaryAttachment),
                                        allowMultipleAttachment = mDatabase?.allowMultipleAttachments ?: true,
                                        attachmentToUploadUri = event.attachmentToUploadUri
                                    )
                                }
                            }
                            is AttachmentsViewModel.AttachmentEvent.OnStartUploadAttachment -> {
                                // Start uploading in service
                                mAttachmentFileBinderManager?.startUploadAttachment(
                                    uploadFileUri = event.attachmentToUploadUri,
                                    attachment = event.attachment
                                )
                            }
                            is AttachmentsViewModel.AttachmentEvent.DeleteAttachment -> {
                                mAttachmentFileBinderManager?.removeBinaryAttachment(event.attachment)
                            }
                            is AttachmentsViewModel.AttachmentEvent.OnAttachmentError -> {
                                coordinatorLayout?.let {
                                    Snackbar.make(it, R.string.error_file_not_create, Snackbar.LENGTH_LONG).asError().show()
                                }
                            }
                            is AttachmentsViewModel.AttachmentEvent.ShowReplaceFile -> {
                                ReplaceFileDialogFragment.build(
                                    event.attachmentToUploadUri,
                                    event.attachment
                                ).show(supportFragmentManager, "replacementFileFragment")
                            }
                            else -> {}
                        }
                    }
                }
                launch {
                    mUserVerificationViewModel.onUserVerificationCanceled.collect { result ->
                        coordinatorLayout?.showError(result.error)
                    }
                }
                launch {
                    mUserVerificationViewModel.onUserVerificationSucceeded.collect { data ->
                        when (data.actionType) {
                            UserVerificationActionType.SHOW_PROTECTED_FIELD -> {
                                data.fieldProtection?.let { fieldProtection ->
                                    mEntryEditViewModel.updateFieldProtection(
                                        fieldProtection = fieldProtection,
                                        isRevealed = true
                                    )
                                }
                            }
                            else -> {}
                        }
                    }
                }
            }
        }
    }

    override fun viewToInvalidateTimeout(): View? = coordinatorLayout

    override fun finishActivityIfReloadRequested(): Boolean = true

    override fun onDatabaseRetrieved(database: ContextualDatabase) {
        super.onDatabaseRetrieved(database)
        mEntryEditViewModel.onDatabaseLoaded(database)
        mTemplatesSelectorAdapter?.apply {
            iconDrawableFactory = database.iconDrawableFactory
            notifyDataSetChanged()
        }
    }

    override fun onDatabaseActionFinished(
        database: ContextualDatabase,
        actionTask: String,
        result: ActionRunnable.Result
    ) {
        super.onDatabaseActionFinished(database, actionTask, result)
        mEntryEditViewModel.unlockAction()
        when (actionTask) {
            ACTION_DATABASE_CREATE_ENTRY_TASK,
            ACTION_DATABASE_UPDATE_ENTRY_TASK -> {
                try {
                    if (result.isSuccess) {
                        result.data?.getNewEntry(database)?.let { entry ->
                            EntrySelectionHelper.doSpecialAction(
                                intent = intent,
                                defaultAction = {
                                    // Finish naturally
                                    finishForEntryResult(entry)
                                },
                                searchAction = {
                                    // Nothing when search retrieved
                                },
                                selectionAction = { _, typeMode, _ ->
                                    when(typeMode) {
                                        TypeMode.DEFAULT -> {}
                                        TypeMode.MAGIKEYBOARD ->
                                            entryValidatedForKeyboardSelection(entry)
                                        TypeMode.AUTOFILL ->
                                            entryValidatedForAutofill(entry)
                                        TypeMode.PASSWORD ->
                                            entryValidatedForPassword(entry)
                                        TypeMode.PASSKEY ->
                                            entryValidatedForPasskey(entry)
                                    }
                                },
                                registrationAction = { _, typeMode, _ ->
                                    when(typeMode) {
                                        TypeMode.DEFAULT ->
                                            entryValidatedForSave(entry)
                                        TypeMode.MAGIKEYBOARD -> {}
                                        TypeMode.AUTOFILL ->
                                            entryValidatedForAutofill(entry)
                                        TypeMode.PASSWORD ->
                                            entryValidatedForPassword(entry)
                                        TypeMode.PASSKEY ->
                                            entryValidatedForPasskey(entry)
                                    }
                                }
                            )
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Unable to retrieve entry after database action", e)
                }
            }
        }
    }

    private fun entryValidatedForSave(entry: EntryInfo) {
        onValidateSpecialMode()
        finishForEntryResult(entry)
    }

    private fun entryValidatedForKeyboardSelection(entry: EntryInfo) {
        // Build Magikeyboard response with the entry selected
        this.buildSpecialModeResponseAndSetResult(
            entryInfo = entry,
            extras = buildEntryResult(entry)
        )
        onValidateSpecialMode()
    }

    private fun entryValidatedForAutofill(entry: EntryInfo) {
        // Build Autofill response with the entry selected
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            this.buildSpecialModeResponseAndSetResult(
                entryInfo = entry,
                extras = buildEntryResult(entry)
            )
        }
        onValidateSpecialMode()
    }

    private fun entryValidatedForPassword(entry: EntryInfo) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            this.buildPasswordResponseAndSetResult(
                entryInfo = entry,
                extras = buildEntryResult(entry)
            )
        }
        onValidateSpecialMode()
    }

    private fun entryValidatedForPasskey(entry: EntryInfo) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            this.buildPasskeyResponseAndSetResult(
                entryInfo = entry,
                extras = buildEntryResult(entry) // To update the previous screen
            )
        }
        onValidateSpecialMode()
    }

    override fun onResume() {
        super.onResume()

        lockView?.visibility = if (PreferencesUtil.showLockDatabaseButton(this)) {
            View.VISIBLE
        } else {
            View.GONE
        }

        // Padding if lock button visible
        entryEditAddToolBar?.updateButtonPaddingStart()
        entryEditAddToolBar?.updateButtonPaddingEnd()

        mAttachmentFileBinderManager?.apply {
            registerProgressTask()
            onActionTaskListener = object : AttachmentFileNotificationService.ActionTaskListener {
                override fun onAttachmentAction(fileUri: Uri, entryAttachmentState: EntryAttachmentState) {
                    mAttachmentsViewModel.onAttachmentAction(entryAttachmentState)
                }
            }
        }

        // Keep the screen on
        if (PreferencesUtil.isKeepScreenOnEnabled(this)) {
            window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    override fun onPause() {
        mAttachmentFileBinderManager?.unregisterProgressTask()

        super.onPause()
    }

    /**
     * Add a new customized field
     */
    private fun addNewCustomField() {
        EntryCustomFieldDialogFragment.getInstance().show(supportFragmentManager, "customFieldDialog")
    }

    private fun editCustomField(field: Field) {
        EntryCustomFieldDialogFragment.getInstance(field).show(supportFragmentManager, "customFieldDialog")
    }

    /**
     * Add a new attachment
     */
    private fun addNewAttachment() {
        mExternalFileHelper?.openDocument()
    }

    /**
     * Set up OTP (HOTP or TOTP) and add it as extra field
     */
    private fun setupOtp() {
        mEntryEditViewModel.setupOtp()
    }

    /**
     * Validate the new entry or update an existing entry in the database
     */
    private fun requestEntryValidation() {
        mAttachmentFileBinderManager?.stopUploadAllAttachments()
        mEntryEditViewModel.requestEntryValidation()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        super.onCreateOptionsMenu(menu)
        if (mEntryEditViewModel.entryLoaded) {
            menuInflater.inflate(R.menu.entry_edit, menu)
            Handler(Looper.getMainLooper()).post {
                performedNextEducation()
            }
        }
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        menu?.findItem(R.id.menu_add_field)?.apply {
            isEnabled = mEntryEditViewModel.allowCustomFields
            isVisible = isEnabled
        }
        menu?.findItem(R.id.menu_add_attachment)?.apply {
            isEnabled = !mEntryEditViewModel.isTemplate
            isVisible = isEnabled
        }
        menu?.findItem(R.id.menu_add_otp)?.apply {
            isEnabled = mEntryEditViewModel.allowOTP && !mEntryEditViewModel.isTemplate
            isVisible = isEnabled
        }
        return super.onPrepareOptionsMenu(menu)
    }

    private fun performedNextEducation() {

        val entryEditFragment = supportFragmentManager.findFragmentById(R.id.entry_edit_content)
                as? EntryEditFragment?
        val generatePasswordView = entryEditFragment?.getActionImageView()
        val generatePasswordEductionPerformed = generatePasswordView != null
                && mEntryEditActivityEducation.checkAndPerformedGeneratePasswordEducation(
            generatePasswordView,
            {
                entryEditFragment.launchGeneratePasswordEductionAction()
            },
            {
                performedNextEducation()
            }
        )

        if (!generatePasswordEductionPerformed) {
            val addNewFieldView: View? = entryEditAddToolBar?.findViewById(R.id.menu_add_field)
            val addNewFieldEducationPerformed = mEntryEditViewModel.allowCustomFields
                    && addNewFieldView != null
                    && addNewFieldView.isVisible
                    && mEntryEditActivityEducation.checkAndPerformedEntryNewFieldEducation(
                    addNewFieldView,
                    {
                        addNewCustomField()
                    },
                    {
                        performedNextEducation()
                    }
            )
            if (!addNewFieldEducationPerformed) {
                val attachmentView: View? = entryEditAddToolBar?.findViewById(R.id.menu_add_attachment)
                val addAttachmentEducationPerformed = attachmentView != null
                        && attachmentView.isVisible
                        && mEntryEditActivityEducation.checkAndPerformedAttachmentEducation(
                        attachmentView,
                        {
                            addNewAttachment()
                        },
                        {
                            performedNextEducation()
                        }
                )
                if (!addAttachmentEducationPerformed) {
                    val setupOtpView: View? = entryEditAddToolBar?.findViewById(R.id.menu_add_otp)
                    val validateEntryEducationPerformed = setupOtpView != null
                            && setupOtpView.isVisible
                            && mEntryEditActivityEducation.checkAndPerformedSetUpOTPEducation(
                            setupOtpView,
                            {
                                setupOtp()
                            },
                            {
                                performedNextEducation()
                            }
                    )
                    if (!validateEntryEducationPerformed) {
                        val entryValidateView = validateButton
                        mEntryEditViewModel.allowCustomFields
                                && entryValidateView != null
                                && entryValidateView.isVisible
                                && mEntryEditActivityEducation.checkAndPerformedValidateEntryEducation(
                                entryValidateView,
                                {
                                    requestEntryValidation()
                                }
                        )
                    }
                }
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_add_field -> {
                addNewCustomField()
                return true
            }
            R.id.menu_add_attachment -> {
                addNewAttachment()
                return true
            }
            R.id.menu_add_otp -> {
                setupOtp()
                return true
            }
            android.R.id.home -> {
                onDatabaseBackPressed()
            }
        }

        return super.onOptionsItemSelected(item)
    }

    override fun onDatabaseBackPressed() {
        mEntryEditViewModel.askToClose(
            EntryEditViewModel.CloseType.DATABASE_BACK_PRESSED
        )
    }

    override fun onCancelSpecialMode() {
        mEntryEditViewModel.askToClose(
            EntryEditViewModel.CloseType.CANCEL_SPECIAL_MODE
        )
    }

    private fun buildEntryResult(entry: EntryInfo): Bundle {
        return Bundle().apply {
            putParcelable(ADD_OR_UPDATE_ENTRY_KEY, entry.nodeId)
        }
    }

    private fun finishForEntryResult(entry: EntryInfo) {
        // Assign entry callback as a result
        try {
            val bundle = buildEntryResult(entry)
            val intentEntry = Intent()
            intentEntry.putExtras(bundle)
            setResult(RESULT_OK, intentEntry)
            super.finish()
        } catch (e: Exception) {
            // Exception when parcelable can't be done
            Log.e(TAG, "Cant add entry as result", e)
        }
    }

    enum class RegistrationType {
        UPDATE, CREATE
    }

    companion object {

        private val TAG = EntryEditActivity::class.java.name

        // Keys for current Activity
        private const val KEY_ENTRY = "entry"
        private const val KEY_PARENT = "parent"
        const val ADD_OR_UPDATE_ENTRY_KEY = "ADD_OR_UPDATE_ENTRY_KEY"

        fun registerForEntryResult(
            activity: FragmentActivity,
            entryAddedOrUpdatedListener: (EntryId?) -> Unit
        ): ActivityResultLauncher<Intent> {
            return activity.registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == RESULT_OK) {
                    entryAddedOrUpdatedListener.invoke(
                        result.data?.getParcelableExtraCompat(ADD_OR_UPDATE_ENTRY_KEY)
                    )
                } else {
                    entryAddedOrUpdatedListener.invoke(null)
                }
            }
        }

        /**
         * Launch EntryEditActivity to update an existing entry or to add a new entry in an existing group
         */
        fun launch(
            activity: Activity,
            database: ContextualDatabase,
            registrationType: RegistrationType,
            nodeId: NodeId<*>,
            activityResultLauncher: ActivityResultLauncher<Intent>
        ) {
            if (database.loaded && !database.isReadOnly) {
                if (TimeoutHelper.checkTimeAndLockIfTimeout(activity)) {
                    val intent = Intent(activity, EntryEditActivity::class.java)
                    when (registrationType) {
                        RegistrationType.UPDATE -> intent.putExtra(KEY_ENTRY, nodeId)
                        RegistrationType.CREATE -> intent.putExtra(KEY_PARENT, nodeId)
                    }
                    activityResultLauncher.launch(intent)
                }
            }
        }

        /**
         * Launch EntryEditActivity to add a new entry in special selection
         */
        fun launchForSelection(
            context: Context,
            database: ContextualDatabase,
            typeMode: TypeMode,
            groupId: GroupId,
            searchInfo: SearchInfo? = null,
            activityResultLauncher: ActivityResultLauncher<Intent>? = null,
        ) {
            if (database.loaded && !database.isReadOnly) {
                if (TimeoutHelper.checkTimeAndLockIfTimeout(context)) {
                    val intent = Intent(context, EntryEditActivity::class.java)
                    intent.putExtra(KEY_PARENT, groupId)
                    EntrySelectionHelper.startActivityForSelectionModeResult(
                        context = context,
                        intent = intent,
                        typeMode = typeMode,
                        searchInfo = searchInfo,
                        activityResultLauncher = activityResultLauncher
                    )
                }
            }
        }

        /**
         * Launch EntryEditActivity to update an updated entry or register a new entry (from autofill)
         */
        fun launchForRegistration(
            context: Context,
            database: ContextualDatabase,
            nodeId: NodeId<*>,
            registerInfo: RegisterInfo? = null,
            typeMode: TypeMode,
            registrationType: RegistrationType,
            activityResultLauncher: ActivityResultLauncher<Intent>? = null,
        ) {
            if (database.loaded && !database.isReadOnly) {
                if (TimeoutHelper.checkTimeAndLockIfTimeout(context)) {
                    val intent = Intent(context, EntryEditActivity::class.java)
                    when (registrationType) {
                        RegistrationType.UPDATE -> intent.putExtra(KEY_ENTRY, nodeId)
                        RegistrationType.CREATE -> intent.putExtra(KEY_PARENT, nodeId)
                    }
                    EntrySelectionHelper.startActivityForRegistrationModeResult(
                        context,
                        activityResultLauncher,
                        intent,
                        registerInfo,
                        typeMode
                    )
                }
            }
        }
    }
}
