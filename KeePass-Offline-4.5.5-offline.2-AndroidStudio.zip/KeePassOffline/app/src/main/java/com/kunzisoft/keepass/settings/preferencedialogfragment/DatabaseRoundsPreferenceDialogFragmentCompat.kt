/*
 * Copyright 2019 Jeremy Jamet / Kunzisoft.
 *
 * This file is part of KeePassDX.
 *
 *  KeePassDX is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  KeePassDX is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with KeePassDX.  If not, see <http://www.gnu.org/licenses/>.
 *
 */
package com.kunzisoft.keepass.settings.preferencedialogfragment

import android.os.Bundle
import android.util.Log
import android.view.View
import com.kunzisoft.keepass.R
import com.kunzisoft.keepass.database.ContextualDatabase
import com.kunzisoft.keepass.database.crypto.kdf.KdfBenchmark
import com.kunzisoft.keepass.database.crypto.kdf.KdfEngine.Companion.DEFAULT_BENCHMARK_TIME
import com.kunzisoft.keepass.services.DatabaseTaskNotificationService.Companion.ACTION_DATABASE_BENCHMARK_KDF
import com.kunzisoft.keepass.services.DatabaseTaskNotificationService.Companion.getParcelableElements
import com.kunzisoft.keepass.tasks.ActionRunnable

class DatabaseRoundsPreferenceDialogFragmentCompat : DatabaseSavePreferenceDialogFragmentCompat() {

    override fun onBindDialogView(view: View) {
        super.onBindDialogView(view)
        explanationText = getString(R.string.rounds_explanation)
        val targetTime = DEFAULT_BENCHMARK_TIME
        setExplanationButton(getString(
            R.string.benchmark_calculation,
            "%.1f".format(targetTime / 1000.0)
        )) {
            mDatabaseViewModel.benchmarkKdf(targetTime)
        }
    }

    override fun onDatabaseRetrieved(database: ContextualDatabase) {
        database.kdfEngine?.getKeyRounds()?.toString()?.let {
            inputText = it
        }
    }

    override fun onDatabaseActionFinished(
        database: ContextualDatabase,
        actionTask: String,
        result: ActionRunnable.Result
    ) {
        super.onDatabaseActionFinished(database, actionTask, result)
        if (actionTask == ACTION_DATABASE_BENCHMARK_KDF) {
            result.data?.getParcelableElements<KdfBenchmark> { _, newBenchmark ->
                newBenchmark?.iterations?.let { benchmark ->
                    inputText = benchmark.toString()
                }
            }
        }
    }

    override fun onDialogClosed(database: ContextualDatabase?, positiveResult: Boolean) {
        if (positiveResult) {
            database?.kdfEngine?.let { kdfEngine ->
                val minIterations = kdfEngine.minKeyRounds
                var newRounds: ULong = try {
                    inputText.toLong().toULong()
                } catch (_: NumberFormatException) {
                    minIterations
                }
                if (newRounds < minIterations) {
                    newRounds = minIterations
                }
                val maxIterations = kdfEngine.maxKeyRounds
                if (newRounds > maxIterations) {
                    newRounds = maxIterations
                    Log.e(TAG, getString(
                        R.string.error_rounds_too_large,
                            maxIterations.toString()))
                }

                val oldRounds = kdfEngine.getKeyRounds()
                kdfEngine.setKeyRounds(newRounds)

                saveIterations(oldRounds.toLong(), newRounds.toLong())
            }
        }
    }

    companion object {
        private val TAG = DatabaseRoundsPreferenceDialogFragmentCompat::class.simpleName

        fun newInstance(key: String): DatabaseRoundsPreferenceDialogFragmentCompat {
            val fragment = DatabaseRoundsPreferenceDialogFragmentCompat()
            val bundle = Bundle(1)
            bundle.putString(ARG_KEY, key)
            fragment.arguments = bundle

            return fragment
        }
    }
}
